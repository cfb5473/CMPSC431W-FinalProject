--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE laptops2024;
--
-- Name: laptops2024; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE laptops2024 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE laptops2024 OWNER TO postgres;

\connect laptops2024

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: graphics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.graphics (
    graphics_id integer NOT NULL,
    laptop_id integer,
    gpu_brand character varying(150),
    gpu_type character varying(150)
);


ALTER TABLE public.graphics OWNER TO postgres;

--
-- Name: graphics_graphics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.graphics_graphics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.graphics_graphics_id_seq OWNER TO postgres;

--
-- Name: graphics_graphics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.graphics_graphics_id_seq OWNED BY public.graphics.graphics_id;


--
-- Name: laptop; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.laptop (
    laptop_id integer NOT NULL,
    model character varying(150),
    is_touch_screen boolean,
    display_size numeric,
    resolution_width integer,
    resolution_height integer
);


ALTER TABLE public.laptop OWNER TO postgres;

--
-- Name: laptop_laptop_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.laptop_laptop_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.laptop_laptop_id_seq OWNER TO postgres;

--
-- Name: laptop_laptop_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.laptop_laptop_id_seq OWNED BY public.laptop.laptop_id;


--
-- Name: memory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memory (
    memory_id integer NOT NULL,
    laptop_id integer,
    ram_memory integer
);


ALTER TABLE public.memory OWNER TO postgres;

--
-- Name: memory_memory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.memory_memory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.memory_memory_id_seq OWNER TO postgres;

--
-- Name: memory_memory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.memory_memory_id_seq OWNED BY public.memory.memory_id;


--
-- Name: processor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.processor (
    processor_id integer NOT NULL,
    laptop_id integer,
    processor_brand character varying(100),
    processor_tier character varying(100),
    num_cores integer,
    num_threads integer
);


ALTER TABLE public.processor OWNER TO postgres;

--
-- Name: processor_processor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.processor_processor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processor_processor_id_seq OWNER TO postgres;

--
-- Name: processor_processor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.processor_processor_id_seq OWNED BY public.processor.processor_id;


--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    product_id integer NOT NULL,
    laptop_id integer,
    brand character varying(100),
    price numeric,
    rating integer,
    os character varying(50),
    year_of_warranty integer,
    CONSTRAINT product_rating_check CHECK (((rating >= 0) AND (rating <= 10)))
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_product_id_seq OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_product_id_seq OWNED BY public.product.product_id;


--
-- Name: storage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storage (
    storage_id integer NOT NULL,
    laptop_id integer,
    primary_storage character varying(100),
    primary_storage_capacity character varying(100),
    secondary_storage character varying(100),
    secondary_storage_capacity character varying(100)
);


ALTER TABLE public.storage OWNER TO postgres;

--
-- Name: storage_storage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.storage_storage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.storage_storage_id_seq OWNER TO postgres;

--
-- Name: storage_storage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.storage_storage_id_seq OWNED BY public.storage.storage_id;


--
-- Name: graphics graphics_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graphics ALTER COLUMN graphics_id SET DEFAULT nextval('public.graphics_graphics_id_seq'::regclass);


--
-- Name: laptop laptop_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.laptop ALTER COLUMN laptop_id SET DEFAULT nextval('public.laptop_laptop_id_seq'::regclass);


--
-- Name: memory memory_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory ALTER COLUMN memory_id SET DEFAULT nextval('public.memory_memory_id_seq'::regclass);


--
-- Name: processor processor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processor ALTER COLUMN processor_id SET DEFAULT nextval('public.processor_processor_id_seq'::regclass);


--
-- Name: product product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN product_id SET DEFAULT nextval('public.product_product_id_seq'::regclass);


--
-- Name: storage storage_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage ALTER COLUMN storage_id SET DEFAULT nextval('public.storage_storage_id_seq'::regclass);


--
-- Data for Name: graphics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.graphics (graphics_id, laptop_id, gpu_brand, gpu_type) FROM stdin;
\.
COPY public.graphics (graphics_id, laptop_id, gpu_brand, gpu_type) FROM '$$PATH$$/4889.dat';

--
-- Data for Name: laptop; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.laptop (laptop_id, model, is_touch_screen, display_size, resolution_width, resolution_height) FROM stdin;
\.
COPY public.laptop (laptop_id, model, is_touch_screen, display_size, resolution_width, resolution_height) FROM '$$PATH$$/4881.dat';

--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.memory (memory_id, laptop_id, ram_memory) FROM stdin;
\.
COPY public.memory (memory_id, laptop_id, ram_memory) FROM '$$PATH$$/4887.dat';

--
-- Data for Name: processor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.processor (processor_id, laptop_id, processor_brand, processor_tier, num_cores, num_threads) FROM stdin;
\.
COPY public.processor (processor_id, laptop_id, processor_brand, processor_tier, num_cores, num_threads) FROM '$$PATH$$/4885.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (product_id, laptop_id, brand, price, rating, os, year_of_warranty) FROM stdin;
\.
COPY public.product (product_id, laptop_id, brand, price, rating, os, year_of_warranty) FROM '$$PATH$$/4891.dat';

--
-- Data for Name: storage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storage (storage_id, laptop_id, primary_storage, primary_storage_capacity, secondary_storage, secondary_storage_capacity) FROM stdin;
\.
COPY public.storage (storage_id, laptop_id, primary_storage, primary_storage_capacity, secondary_storage, secondary_storage_capacity) FROM '$$PATH$$/4883.dat';

--
-- Name: graphics_graphics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.graphics_graphics_id_seq', 2, true);


--
-- Name: laptop_laptop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.laptop_laptop_id_seq', 34, true);


--
-- Name: memory_memory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.memory_memory_id_seq', 4, true);


--
-- Name: processor_processor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.processor_processor_id_seq', 5, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_product_id_seq', 11, true);


--
-- Name: storage_storage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.storage_storage_id_seq', 2, true);


--
-- Name: graphics graphics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graphics
    ADD CONSTRAINT graphics_pkey PRIMARY KEY (graphics_id);


--
-- Name: laptop laptop_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.laptop
    ADD CONSTRAINT laptop_pkey PRIMARY KEY (laptop_id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (memory_id);


--
-- Name: processor processor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processor
    ADD CONSTRAINT processor_pkey PRIMARY KEY (processor_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: storage storage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage
    ADD CONSTRAINT storage_pkey PRIMARY KEY (storage_id);


--
-- Name: graphics graphics_laptop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.graphics
    ADD CONSTRAINT graphics_laptop_id_fkey FOREIGN KEY (laptop_id) REFERENCES public.laptop(laptop_id);


--
-- Name: memory memory_laptop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_laptop_id_fkey FOREIGN KEY (laptop_id) REFERENCES public.laptop(laptop_id);


--
-- Name: processor processor_laptop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processor
    ADD CONSTRAINT processor_laptop_id_fkey FOREIGN KEY (laptop_id) REFERENCES public.laptop(laptop_id);


--
-- Name: product product_laptop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_laptop_id_fkey FOREIGN KEY (laptop_id) REFERENCES public.laptop(laptop_id);


--
-- Name: storage storage_laptop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage
    ADD CONSTRAINT storage_laptop_id_fkey FOREIGN KEY (laptop_id) REFERENCES public.laptop(laptop_id);


--
-- PostgreSQL database dump complete
--

